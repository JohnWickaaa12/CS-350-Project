#
# Thermostat.py - CS 350 Final Project
#
# Smart thermostat with three states: off, heat, cool.
# Uses an AHT20 sensor, LCD, buttons, LEDs, and UART.
#

from time import sleep
from datetime import datetime
from threading import Thread, Lock
from math import floor

from statemachine import StateMachine, State

import board
import digitalio
import adafruit_ahtx0
import adafruit_character_lcd.character_lcd as characterlcd
import serial

from gpiozero import Button, PWMLED


# Enable console messages for testing
DEBUG = True

# Initialize the I2C bus and temperature sensor
i2c = board.I2C()
thSensor = adafruit_ahtx0.AHTx0(i2c)

# Initialize UART serial communication
ser = serial.Serial(
    port="/dev/ttyS0",
    baudrate=115200,
    parity=serial.PARITY_NONE,
    stopbits=serial.STOPBITS_ONE,
    bytesize=serial.EIGHTBITS,
    timeout=1
)

# Initialize LED outputs
redLight = PWMLED(18)
blueLight = PWMLED(23)


# Manage the 16x2 LCD display
class ManagedDisplay:

    def __init__(self):
        self.lcd_rs = digitalio.DigitalInOut(board.D17)
        self.lcd_en = digitalio.DigitalInOut(board.D27)
        self.lcd_d4 = digitalio.DigitalInOut(board.D5)
        self.lcd_d5 = digitalio.DigitalInOut(board.D6)
        self.lcd_d6 = digitalio.DigitalInOut(board.D13)
        self.lcd_d7 = digitalio.DigitalInOut(board.D26)

        self.lcd_columns = 16
        self.lcd_rows = 2

        self.lcd = characterlcd.Character_LCD_Mono(
            self.lcd_rs,
            self.lcd_en,
            self.lcd_d4,
            self.lcd_d5,
            self.lcd_d6,
            self.lcd_d7,
            self.lcd_columns,
            self.lcd_rows
        )

        self.lcd.clear()

    def cleanupDisplay(self):
        self.lcd.clear()
        self.lcd_rs.deinit()
        self.lcd_en.deinit()
        self.lcd_d4.deinit()
        self.lcd_d5.deinit()
        self.lcd_d6.deinit()
        self.lcd_d7.deinit()

    def clear(self):
        self.lcd.clear()

    def updateScreen(self, message):
        self.lcd.clear()
        self.lcd.message = message


# Initialize LCD
screen = ManagedDisplay()


# Thermostat state machine
class TemperatureMachine(StateMachine):

    # Define thermostat states
    off = State(initial=True)
    heat = State()
    cool = State()

    # Define state transitions
    cycle = (
        off.to(heat) |
        heat.to(cool) |
        cool.to(off)
    )

    def __init__(self):
        self.setPoint = 72
        self.endDisplay = False
        self.lock = Lock()
        super().__init__()

    # Enter heating mode
    def on_enter_heat(self):
        if DEBUG:
            print("* Changing state to heat")

        self.updateLights()

    # Exit heating mode
    def on_exit_heat(self):
        redLight.off()

    # Enter cooling mode
    def on_enter_cool(self):
        if DEBUG:
            print("* Changing state to cool")

        self.updateLights()

    # Exit cooling mode
    def on_exit_cool(self):
        blueLight.off()

    # Enter off mode
    def on_enter_off(self):
        redLight.off()
        blueLight.off()

        if DEBUG:
            print("* Changing state to off")

    # Green button changes thermostat mode
    def processTempStateButton(self):
        if DEBUG:
            print("Cycling Temperature State")

        with self.lock:
            self.cycle()

    # Red button increases temperature set point
    def processTempIncButton(self):
        with self.lock:
            self.setPoint += 1

            if DEBUG:
                print(f"Increasing Set Point: {self.setPoint}")

            self.updateLights()

    # Blue button decreases temperature set point
    def processTempDecButton(self):
        with self.lock:
            self.setPoint -= 1

            if DEBUG:
                print(f"Decreasing Set Point: {self.setPoint}")

            self.updateLights()

    # Read temperature in Fahrenheit
    def getFahrenheit(self):
        temperature = thSensor.temperature
        return ((9 / 5) * temperature) + 32

    # Update heating and cooling LEDs
    def updateLights(self):
        temp = floor(self.getFahrenheit())

        redLight.off()
        blueLight.off()

        current_state = self.current_state.id

        if DEBUG:
            print(f"State: {current_state}")
            print(f"SetPoint: {self.setPoint}")
            print(f"Temp: {temp}")

        if current_state == "heat":

            if temp < self.setPoint:
                # Heating is active
                redLight.pulse(
                    fade_in_time=1,
                    fade_out_time=1,
                    n=None,
                    background=True
                )
            else:
                # Set point reached
                redLight.on()

        elif current_state == "cool":

            if temp > self.setPoint:
                # Cooling is active
                blueLight.pulse(
                    fade_in_time=1,
                    fade_out_time=1,
                    n=None,
                    background=True
                )
            else:
                # Set point reached
                blueLight.on()

        else:
            # Thermostat is off
            redLight.off()
            blueLight.off()

    # Format data for serial transmission
    def setupSerialOutput(self):
        current_state = self.current_state.id
        current_temp = self.getFahrenheit()

        output = (
            f"{current_state},"
            f"{current_temp:.1f},"
            f"{self.setPoint}\n"
        )

        return output

    # Start the LCD management thread
    def run(self):
        self.displayThread = Thread(
            target=self.manageMyDisplay
        )
        self.displayThread.start()

    # Update LCD and UART
    def manageMyDisplay(self):
        counter = 0
        altCounter = 0

        while not self.endDisplay:

            try:
                current_time = datetime.now()

                # LCD first line: date and time
                lcd_line_1 = current_time.strftime(
                    "%m/%d %H:%M:%S"
                )[:16]

                with self.lock:
                    current_temp = self.getFahrenheit()
                    current_state = self.current_state.id
                    current_setpoint = self.setPoint

                    # Update LED status every 10 seconds
                    if counter % 10 == 0:
                        self.updateLights()

                    # Send UART data every 30 seconds
                    if counter > 0 and counter % 30 == 0:
                        output = self.setupSerialOutput()

                        ser.write(output.encode("utf-8"))

                        if DEBUG:
                            print(f"UART: {output.strip()}")

                # Alternate LCD second line every 5 seconds
                if altCounter < 5:
                    lcd_line_2 = (
                        f"Temp: {current_temp:.1f} F"
                    )
                else:
                    lcd_line_2 = (
                        f"{current_state.upper()} "
                        f"Set: {current_setpoint} F"
                    )

                # Ensure both lines fit the LCD
                lcd_line_1 = lcd_line_1.ljust(16)[:16]
                lcd_line_2 = lcd_line_2.ljust(16)[:16]

                # Update LCD display
                screen.updateScreen(
                    lcd_line_1 + "\n" + lcd_line_2
                )

                if DEBUG:
                    print(
                        f"{current_state.upper()} | "
                        f"Temp: {current_temp:.1f} F | "
                        f"Set Point: {current_setpoint} F"
                    )

                counter += 1
                altCounter += 1

                if altCounter >= 10:
                    altCounter = 0

                sleep(1)

            except Exception as error:
                print(f"Display error: {error}")
                sleep(1)

        screen.cleanupDisplay()


# Main program
tsm = None
greenButton = None
redButton = None
blueButton = None

try:
    # Initialize thermostat state machine
    tsm = TemperatureMachine()

    # Initialize buttons
    greenButton = Button(24, pull_up=True, bounce_time=0.2)
    redButton = Button(25, pull_up=True, bounce_time=0.2)
    blueButton = Button(12, pull_up=True, bounce_time=0.2)

    # Assign button press handlers
    greenButton.when_pressed = tsm.processTempStateButton
    redButton.when_pressed = tsm.processTempIncButton
    blueButton.when_pressed = tsm.processTempDecButton

    # Start LCD and temperature monitoring
    tsm.run()

    print("Thermostat Started")
    print("Default Set Point: 72 F")
    print("Green Button: Change Mode")
    print("Red Button: Increase Set Point")
    print("Blue Button: Decrease Set Point")
    print("Press CTRL+C to exit")

    # Keep the program running
    while True:
        sleep(1)

except KeyboardInterrupt:
    print("\nCleaning up. Exiting...")

finally:
    # Stop display thread
    if tsm is not None:
        tsm.endDisplay = True

        if hasattr(tsm, "displayThread"):
            tsm.displayThread.join()

    # Turn off LEDs
    redLight.off()
    blueLight.off()

    # Release GPIO resources
    if greenButton is not None:
        greenButton.close()

    if redButton is not None:
        redButton.close()

    if blueButton is not None:
        blueButton.close()

    redLight.close()
    blueLight.close()

    # Close UART
    ser.close()

    print("Thermostat stopped.")